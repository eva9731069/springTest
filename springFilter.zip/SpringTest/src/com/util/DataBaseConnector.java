package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnector {

	static final String DB_URL = "jdbc:oracle:thin:@//ihadb.intranet.idc:1521/tpdbp01";

	// Database credentials
	static final String USER = "s093";
	static final String PASS = "s093";

	public static Connection getConnection() {
		Connection conn = null;

		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}
