package com.login.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.login.dao.LoginDao;
import com.login.vo.LoginVo;
import com.util.DataBaseConnector;

public class LoginDaoImpl implements LoginDao {

	@Override
	public void update(String sql) {
		try (Connection connection = DataBaseConnector.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<LoginVo> query(String sql) {
		try (Connection connection = DataBaseConnector.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql)) {
			ResultSet rs = stmt.executeQuery(sql);
			List<LoginVo> list = new ArrayList<>();
			String kind = "查無資料";
			while (rs.next()) {
				LoginVo detail = new LoginVo();
				kind = rs.getString("kind");
				detail.setKind(kind);
				list.add(detail);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Collections.emptyList();
	}

	@Override
	public void update(LoginVo Vo) {
		// TODO Auto-generated method stub
		
	}

}
