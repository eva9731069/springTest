package com.login.dao;

import java.util.List;

import com.login.vo.LoginVo;

public interface LoginDao {
	
	public void update(String sql);

	public List<LoginVo> query(String sql);

	void update(LoginVo Vo);
	
}
