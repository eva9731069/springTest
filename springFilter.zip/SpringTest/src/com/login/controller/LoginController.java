package com.login.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.login.dao.LoginDao;
import com.login.dao.impl.LoginDaoImpl;
import com.login.vo.LoginVo;

@Controller
@RequestMapping("/")
public class LoginController {

	LoginDao loginDao = new LoginDaoImpl();

	private static final String MESSAGE = "message";

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap model, HttpSession session, HttpServletRequest req) {

		String message = "Hello Spring MVC Framework!";

		String account = (String) session.getAttribute(MESSAGE);

		if (account != null) {
			message = account;
		}

		model.addAttribute(MESSAGE, message);

		return "hello/hello";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public String login(@RequestParam("kind") String kind, ModelMap model, HttpSession session,
			HttpServletRequest req) {

		String sql = "select kind from s093.codedetail where kind in ('@')";
		List<LoginVo> list = loginDao.query(sql.replace("@", kind));
		System.out.println(sql.replace("@", kind));

		String message = "登入失敗";
		String page = "hello/success";
		if (!list.isEmpty()) {
			req.setAttribute("account", kind);
			message = "登入成功";
			System.out.println("登入成功");
		}
		model.addAttribute(MESSAGE, message);

		return page;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/registPage")
	public String registPage(ModelMap model, HttpSession session, HttpServletRequest req) {
		return "hello/regist";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/regist")
	public String regist(@RequestParam("kind") String kind, @RequestParam("code") String code, ModelMap model,
			HttpSession session, HttpServletRequest req) {

		String message = "註冊失敗";

		try {
			// 檢查是否已註冊
			String querySql = "select kind from s093.codedetail where kind= '@kind' and code= '@code'";
			List<LoginVo> list = loginDao.query(querySql.replace("@kind", kind).replace("@code", code));

			if (list.isEmpty()) {
				String insertSql = "insert into s093.codedetail(kind, code) VALUES ('@kind', '@code')";
				loginDao.update(insertSql.replace("@kind", kind).replace("@code", code));
				message = "註冊成功";
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		model.addAttribute(MESSAGE, message);

		return "hello/hello";
	}

}
