package junit;

import com.login.dao.LoginDao;
import com.login.dao.impl.LoginDaoImpl;

public class test {

	LoginDao loginDao = new LoginDaoImpl();


//	@Test
//	public void test() {
//		String sql = "update s093.codedetail set code='P' where id='7'";
//		loginDao.update(sql);
//		System.out.println("success");
//
//	}
//
//	@Test
//	public void testDeca() {
//		String sql = "insert into s093.codedetail(kind, code) VALUES ('@kind','@code')";
//		String kind = "10";
//		String code = "20";
//
//		System.out.println(sql.replace("@kind", kind).replace("@code", code));
//
//	}

//	@Test
//	public void test1() {
//
//		ApplicationContext ctx = new ClassPathXmlApplicationContext("SpringTest-servlet.xml");
//
//		LoginDao userDao = ctx.getBean("Testa", LoginDao.class);
//
//		LoginVo Vo = new LoginVo();
//		Vo.setKind("7");
//		
//		userDao.update(Vo);
//
//		System.out.println("success");
//
//	}

}
